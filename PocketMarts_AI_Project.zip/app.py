from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def home():
    return jsonify({
        "project": "PocketMarts AI",
        "status": "running",
        "message": "Welcome to PocketMarts AI"
    })

@app.route("/products")
def products():
    return jsonify([
        {"id": 1, "name": "Rice", "category": "Grocery"},
        {"id": 2, "name": "Milk", "category": "Dairy"},
        {"id": 3, "name": "Biscuits", "category": "Snacks"}
    ])

@app.route("/recommendations")
def recommendations():
    return jsonify({
        "recommendations": [
            "Rice",
            "Milk",
            "Biscuits"
        ]
    })

if __name__ == "__main__":
    app.run(debug=True)
